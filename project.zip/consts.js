module.exports  = {
    MLAB_URL:'mongodb://ds161804.mlab.com:61804/db_myshelter', 
    DB_USER:'shelter',
    DB_PASS:'Ns20192019'
}
